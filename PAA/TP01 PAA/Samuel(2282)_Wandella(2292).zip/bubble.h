#ifndef BUBBLE_H
#define BUBBLE_H

void bubble(int *A, int n, int *contaComparacao);

#endif /* BUBBLE_H */

