#ifndef QUICK_SORT_H
#define QUICK_SORT_H


void QuickSort(int *A, int tam, int *contaComparacao);

#endif /* QUICK_SORT_H */

